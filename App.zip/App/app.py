import numpy as np
from flask import Flask, request, render_template
from joblib import load
from pathlib import Path
import os
from sklearn.preprocessing import  OneHotEncoder
from sklearn.ensemble import RandomForestClassifier

#PROJECT_ROOT = Path(os.path.abspath('')).resolve().parents[0]
app = Flask(__name__)  # Initialize the flask App

RF_from_joblib = load(r"C:\Users\Utilizador\OneDrive - NOVAIMS\2º Semester\Business Cases with Data Science\PROJETOS\Business_Case_2\App\analysis\RF.pkl")
ohc_from_joblib = load(r"C:\Users\Utilizador\OneDrive - NOVAIMS\2º Semester\Business Cases with Data Science\PROJETOS\Business_Case_2\App\analysis\ohc.pkl")

#ohc_from_joblib =load('ohc.pkl')
#RF_from_joblib = load('RF.pkl')

@app.route('/')
def home():
	return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
    #CATEGORICAL FEATURES:
        #Meal_var ='HB'
        #MarketSegment_var ='Offline TA/TO'
        #DistributionChannel_var = 'TA/TO'
        #ReservedRoomType_var = 'A'
        #AssignedRoomType_var = 'A'
        #CustomerType_var = 'Transient'
        #IsRepeatedGuest_var = 0

        Meal_var =str(request.form['Meal_var'])
        MarketSegment_var =str(request.form['MarketSegment_var'])
        DistributionChannel_var = str(request.form['DistributionChannel_var'])
        ReservedRoomType_var = str(request.form['ReservedRoomType_var'])
        AssignedRoomType_var = str(request.form['AssignedRoomType_var'])
        CustomerType_var = str(request.form['CustomerType_var'])
        IsRepeatedGuest_var = int(request.form['IsRepeatedGuest_var'])

        if Meal_var == 'HB':
            Meal_var = "1 and 2 meal packages"
        if Meal_var == 'BB':
            Meal_var = "1 and 2 meal packages"
        sample_of_categ = np.array([Meal_var, MarketSegment_var, DistributionChannel_var, ReservedRoomType_var, AssignedRoomType_var,CustomerType_var]).reshape(1, -1)
        sample_of_categ = np.append(ohc_from_joblib.transform(sample_of_categ), IsRepeatedGuest_var)
    
    
    #METRIC FEATURES:
        LeadTime = int(request.form['LeadTime'])
        StaysInWeekendNights = int(request.form['StaysInWeekendNights'])
        StaysInWeekNights = int(request.form['StaysInWeekNights'])
        Adults = int(request.form['Adults'])
        Children = int(request.form['Children'])
        Babies = int(request.form['Babies'])
        PreviousCancellations = int(request.form['PreviousCancellations'])
        PreviousBookingsNotCanceled = int(request.form['PreviousBookingsNotCanceled'])
        BookingChanges = int(request.form['BookingChanges'])
        DaysInWaitingList = int(request.form['DaysInWaitingList'])
        ADR = float(request.form['ADR'])
        RequiredCarParkingSpaces = int(request.form['RequiredCarParkingSpaces'])
        TotalOfSpecialRequests = int(request.form['TotalOfSpecialRequests'])
        
        metric_vars =[LeadTime, StaysInWeekendNights, StaysInWeekNights, Adults,Children, Babies, PreviousCancellations,
PreviousBookingsNotCanceled, BookingChanges, DaysInWaitingList,ADR, RequiredCarParkingSpaces, TotalOfSpecialRequests]   
        sample = np.append(metric_vars,sample_of_categ)    
        
       
        my_prediction = RF_from_joblib.predict(sample.reshape(1, -1))
        prob_cancel = round((RF_from_joblib.predict_proba(sample.reshape(1, -1))[0,1] * 100),2)
        prob_not_cancel = round((RF_from_joblib.predict_proba(sample.reshape(1, -1))[0, 0] * 100), 2)
        return render_template('result.html', prediction=my_prediction,prob_cancel=prob_cancel,prob_not_cancel=prob_not_cancel)

if __name__ == '__main__':
	app.run(debug=True)